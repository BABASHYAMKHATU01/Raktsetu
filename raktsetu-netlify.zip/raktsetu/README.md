# RaktSetu (Netlify-ready prototype)

```
raktsetu/
├── netlify.toml      # publish dir + security headers
├── README.md
└── public/
    └── index.html    # the whole site (HTML + CSS + JS)
```

## Run locally
```bash
cd raktsetu
npx serve public        # or: python3 -m http.server -d public 8080
```
The feedback form is saved on your device when run locally. It is delivered to Netlify once deployed.

## Deploy from the terminal
```bash
# 1. Install Node.js 18+ from https://nodejs.org, then:
npm install -g netlify-cli

# 2. Log in (opens the browser once)
netlify login

# 3. From the raktsetu folder, create the site
cd raktsetu
netlify init --manual        # or: netlify sites:create --name raktsetu-yourname

# 4. Draft deploy (preview URL, safe to test)
netlify deploy --dir=public

# 5. Production deploy
netlify deploy --dir=public --prod
```
No install option: `npx netlify-cli deploy --dir=public --prod`

Redeploy after any change: `netlify deploy --dir=public --prod`

## After the first deploy
- **Feedback inbox:** Netlify dashboard > your site > **Forms** > `feedback`.
  Add email alerts under **Forms > Form notifications**. Spam protection: honeypot is already on.
- **Custom domain:** Site configuration > Domain management.
- Forms are detected at deploy time, so if the Forms tab is empty, redeploy once.

## Notes
- Map tiles: OpenStreetMap data via CARTO. Routes: public OSRM demo server. Hospital lookup: OSM Nominatim.
  These free public services are fine for a demo. For real traffic, use a paid or self-hosted provider.
- If routing or hospital lookup fails, the app falls back to a straight-line path / approximate location.
- Banks, donors, ambulance and driver are demo data.
